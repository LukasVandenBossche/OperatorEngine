package Operations;

import java.util.*;

/**
 * @author lukas on 19/12/2019
 * @project OperatorEngine
 */

public class OperationEngine {
    private Operation operation;
    private StringBuilder operandsRegex;

    public OperationEngine(String input, boolean print) {
        BinaryOperation.Operand[] operands = BinaryOperation.Operand.values();
        this.operandsRegex = new StringBuilder("[");
        for (BinaryOperation.Operand operand : operands) {
            if (operand.op == '-' || operand.op == '^') {
                operandsRegex.append("\\").append(operand.op);
            } else {
                operandsRegex.append(operand.op);
            }
        }
        operandsRegex.append("]");
        String opRegex = "[0-9]+( " + operandsRegex + " [0-9]+)*";
        if (input.matches(opRegex)) {
            if (print) System.out.println(input);
            List<String> opString = addParentheses(input);
            if (print) System.out.println(" = " + opString.toString().replaceAll("[,\\[\\]]", ""));
            this.operation = createOp(opString);
        } else {
            throw new InputMismatchException("\nInput \"" + input + "\" contains invalid characters.\n" +
                    "It can only contain numbers or " + operandsRegex + ", all separated by a space.");
        }
    }

    /**
     * creates an operation based on a string
     * order of operations is defined by parentheses
     *
     * @param input list of inputString
     * @return BinaryOperation or Operation object
     */
    private Operation createOp(List<String> input) {
        if (input.size() == 0) throw new NullPointerException("Input is an empty array.");
        if (input.size() == 1) {
            if (input.get(0).contains("(")) {
                String noParentheses = input.get(0).substring(1, input.get(0).length() - 1);
                if (noParentheses.charAt(0) == '(') {
                    List<String> temp = new ArrayList<>();
                    temp.add(noParentheses.replaceAll("(\\(.*\\)).*", "$1"));
                    temp.addAll(Arrays.asList(noParentheses.replaceAll("( \\(.*\\))|(\\(.*\\) )", "")
                            .split(" ")));
                    return createOp(temp);
                } else if (noParentheses.charAt(noParentheses.length()-1) == ')') {
                    List<String> temp = new ArrayList<>(Arrays.asList(noParentheses
                            .replaceAll("( \\(.*\\))|(\\(.*\\) )", "").split(" ")));
                    temp.add(noParentheses.replaceAll("(\\(.*\\)).*", "$1"));
                    return createOp(temp);
                } else {
                    return createOp(new ArrayList<>(Arrays.asList(noParentheses.split(" "))));
                }
            } else {
                return new Operation(Double.parseDouble(input.get(0)));
            }
        }
        Operation lastOp = createOp(new ArrayList<>(Collections.singleton(input.get(0))));
        for (int i = 0; i < input.size(); i++) {
            if (input.get(i).matches(operandsRegex.toString())) {
                lastOp = new BinaryOperation(lastOp,  input.get(i).charAt(0),
                        createOp(new ArrayList<>(Collections.singleton(input.get(i+1)))));
            }
        }
        return lastOp;
    }

    /**
     * creates an order of operations by adding parentheses where needed
     *
     * @param input inputString
     * @return list of input string with added "()", operands are surrounded by spaces
     */
    private static List<String> addParentheses(String input) {
        if (input.length() == 0) throw new NullPointerException("Input is an empty string.");
        List<String> list = Arrays.asList(input.split(" "));
        if (!input.contains("*") && !input.contains("/")) {
            return list;
        }
        boolean done = false;
        while (!done) {
            List<String> temp = new ArrayList<>(list);
            for (int i = 0; i <= list.size(); i++) {
                if (i == list.size()) {
                    done = true;
                    break;
                }
                if (list.get(i).equals("*") || list.get(i).equals("/")) {
                    String op = "(" + list.get(i-1) + " "+ list.get(i) + " " + list.get(i+1) + ")";
                    temp.remove(i-1); temp.remove(i-1); temp.remove(i-1);
                    temp.add(i-1, op);
                    break;
                }
            }
            list = new ArrayList<>(temp);
        }
        return list;
    }

    /**
     * calculates the total from operation
     *
     * @return the result
     */
    public double calculate() {
        return operation.calculate();
    }

    public static void main(String[] args) {
        String[] inputs = new String[]{
                "50 - 30 / 5 - 4", "50 + 10 + 20 - 30", "7 / 7 + 8 / 8", "4 + 50) * 50 / 10", "500", "8 ^ 2"
        };
        for (String input : inputs) {
            try {
                System.out.println(" = " + new OperationEngine(input, true).calculate());
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
}
