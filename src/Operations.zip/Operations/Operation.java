package Operations;

/**
 * @author lukas on 19/12/2019
 * @project OperatorEngine
 */

class Operation {
    private double a;

    Operation(double a) {
        this.a = a;
    }

    double calculate() {
        return a;
    }
}
