package Operations;

import java.util.Arrays;
import java.util.InputMismatchException;

/**
 * @author lukas on 19/12/2019
 * @project OperatorEngine
 */

class BinaryOperation extends Operation {
    enum Operand {
        ADD('+'),
        SUB('-'),
        MUL('*'),
        DIV('/'),
        MOD('%'),
        POW('^');

        public char op;

        Operand(char op) {
            this.op = op;
        }

        static Operand getOperand(char opString) {
            for (Operand operand : Operand.values()) {
                if (operand.op == opString) {
                    return operand;
                }
            }
            throw new InputMismatchException("Variable opString is an invalid operation, it can only be " + Arrays.toString(Operand.values()));
        }
    }

    private Operation a;
    private Operand operand;
    private Operation b;

    BinaryOperation(Operation a, char opString, Operation b) {
        super(0);
        this.a = a;
        this.operand = Operand.getOperand(opString);
        this.b = b;
    }

    @Override
    double calculate() {
        switch (operand) {
            case ADD:
                return a.calculate() + b.calculate();
            case SUB:
                return a.calculate() - b.calculate();
            case MUL:
                return a.calculate() * b.calculate();
            case DIV:
                return a.calculate() / b.calculate();
            case MOD:
                return a.calculate() % b.calculate();
            case POW:
                return Math.pow(a.calculate(), b.calculate());
        }
        return 0.0;
    }
}


